#ifndef MATCHMAKING_H
#define MATCHMAKING_H

#include <string>
#include <fstream>
#include <string>
#include <iostream>



using namespace std;


class Matchmaking {
public:

    static const int MAX_USERNAME_LENGTH = 50;
    static const int MAX_QUEUE_SIZE = 100;


    struct MatchPlayer 
    {
        char username[MAX_USERNAME_LENGTH];
        int highestScore;
        int queueEntryOrder;
    };

   
    MatchPlayer players[MAX_QUEUE_SIZE];
    int frontIndex;
    int rearIndex;
    int currentSize;
    int nextEntryOrder;

   
    void copyString(char* destination, const string& source);
    int stringToInt(const string& str);
    int readUserHighestScore(const string& username);
    void sortQueueByPriority();
    bool arePlayersUnique(const MatchPlayer& p1, const MatchPlayer& p2);

    void populateQueueFromLeaderboard(const string& loggedInUser);

   // void logMatchmakingEvent(const string& eventDescription);




public:
 
    Matchmaking();
    //void debugPrintQueue();
   
    bool enterQueue(const string& username, int hs);

    // void populateQueueFromLeaderboard();


    bool matchPlayers(string& player1Username, string& player2Username);

    int getQueueSize() const;

    
    void clearQueue();
    string getNextTopPlayerFromLeaderboard(const string& topPlayerUsername);
    string getTopPlayerFromLeaderboard();
};

#endif