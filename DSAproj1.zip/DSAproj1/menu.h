#pragma once

#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>
#include "level.h"
#include "auth.h"
#include "leaderboard.h"
#include "matchmaking.h"
#include "friendlist.h"
#include "playerhash.h"
#include "theme.h"
#include "Sprite.h"
#include "player.h"
using namespace sf;
using namespace std;

class Menu {
private:
    RenderWindow& window;
    Font font;

    Leaderboard leaderboard;

    // Main menu text
    Text startText;
    Text selectLevelText;
    Text leaderboardText;
    Text profileText;
	MySprite bgSprite;
    // End menu text
    Text endText;
    Text finalScoreText;

    Level level;  // Reference to level class
    MySprite bgMode;

    MySprite bgLevel;

    void initMainMenu();
    void initEndMenu();

public:
    // Matchmaking and game state variables
    bool isMatchmakingEnabled;
    bool showingMatchmakingQueue;

    string matchedPlayer1;  // First player's username (single declaration)
    string matchedPlayer2;  // Second player's username (single declaration)
    Matchmaking matchmaker;

    // Player usernames
    string player1Username;
    string player2Username;

    // Player profile
    PlayerProfile* currentProfile;
    void handleModeSelection();

    // Level and game state
    int currentLevel;
    bool showingMainMenu = true;
    bool showingModeSelection = false;
    bool showingLevelSelection = false;
    bool gameStarted = false;
    bool isSinglePlayerSelected = true;

    // Set current level
    void setCurrentLevel(int level) {
        currentLevel = level;
    }
    // ThemeInventory themeInventory;
    sf::Text themeSelectionText;

    // Menu display functions
    void displayLevelSelection();
    void handleLevelSelection();
    void displayMainMenu();
    void handleMainMenu();
    void selectMode();

    void selectLevel();

    // Leaderboard methods
    void setLeaderboardDisplayMode(int mode);
    void showLeaderboard();

    // Game management methods
    void displayEndMenu(int score, int highScore);
    void handleEndMenu();
    void showProfile();
    void showMatchmakingQueue();
    bool startMatchmaking();
    void handleMatchmakingQueue();

    // Constructor and Destructor
    Menu(RenderWindow& window, const string& username, Authentication& authRef);
    ~Menu();

    // Game control methods
    void startGame();
    void restartGame();
    bool isPlayerInQueue(const string& username);
    void exitGame();
    int getCurrentLevel();

    MySprite bgLeaderboard;


    MySprite bgFriends;



    MySprite bgPlayer;

    // Score tracking
    int player1Score = 0;
    int player2Score = 0;
    bool restartRequested = false;

    void showFriendsForMultiplayer();








    // Queue status text
    Text queueStatusText;


    void setSecondPlayerName(const string& playerName);
    string secondPlayerName;

    string promptForSecondPlayerName();


    string getValidPlayerName(const string& name, const string& defaultName);

    void syncPlayerNames();



    //friendlist 
    // 
    Text friendListText;                // Text for Friends List menu option

    // New methods for friend list management
    void displayFriendList();           // Display friend list screen
    void handleFriendListInteractions();// Handle user interactions in friend list
    void sendFriendRequest();           // Open window to send friend request
    void displayFriendRequests();
    void showFriendList();
    bool showingFriendList = false;
    Authentication& auth;
    void sendFriendRequestToUser(const string& sender, const string& receiver);



    void acceptFriendRequest();  // Function signature for accepting friend requests
    void rejectFriendRequest();



	int themeSelection();





};