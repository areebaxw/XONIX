#ifndef PLAYERPROFILE_H
#define PLAYERPROFILE_H

#include <SFML/Graphics.hpp>
#include <string>
#include <fstream>
#include "friendlist.h"
#include "Sprite.h"

const int MAX_FRIENDS = 10;
const int MAX_MATCH_HISTORY = 20;

struct MatchRecord {
    string date;
    bool isWin;
    int score;
    string gameMode;
};

class PlayerProfile {
private:
    string username;
    string friends[MAX_FRIENDS];
    int friendCount;
    MatchRecord matchHistory[MAX_MATCH_HISTORY];
    int matchHistoryCount;
    int highestScore;
    sf::Font font;
    sf::Text profileText;

    // Private method to save profile data
    void saveProfileData();

    // Private method to load profile data
    void loadProfileData();

public:
    PlayerProfile(const string& username);

    // Getters
    string getUsername() const;
    int getHighestScore() const;
    int getFriendCount() const;
    int getMatchHistoryCount() const;
    void getFriendsList(string friendsList[]) const;
    void getMatchHistory(MatchRecord matchList[]) const;

    // Methods to modify profile
    bool addFriend(const string& friendUsername);
    bool removeFriend(const string& friendUsername);
    void recordMatch(const MatchRecord& match);
    void updateHighestScore(int newScore);

    // Method to display profile
    void displayProfile(sf::RenderWindow& window, MySprite& bgSprite);

    // Method to handle profile interactions
    bool handleProfileInput(sf::Event& event);



    FriendList* friendList;  // Instance of FriendList
    void loadFriendRequestsFromFile(const string& username) {
        friendList->loadFriendRequestsFromFile(username);  // Delegate to FriendList
    }

    void getFriendRequestsList(string requestsList[], int& count) const {
        friendList->getFriendRequestsList(requestsList, count);  // Delegate to FriendList
    }

    void acceptFriendRequest(const string& username) {
        friendList->acceptFriendRequest(username);  // Delegate the request to FriendList
    }

    void rejectFriendRequest(const string& username) {
        friendList->rejectFriendRequest(username);  // Delegate the request to FriendList
    }



    // Function to save friends list to file
    void saveFriendsToFile(const string& username);

    // Function to save friend requests list to file
    void saveFriendRequestsToFile(const string& username);  // Function declaration
    int extractNumber(const string& str, int startPos);
};

#endif // PLAYERPROFILE_H