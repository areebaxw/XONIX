#ifndef PLAYER_HASH_H
#define PLAYER_HASH_H

#include <string>
#include "friendlist.h"

class PlayerHashTable {
private:
    static const int tablesize = 100;

    struct HashNode {
        string username;
        FriendList friendList;  // Each node now has a FriendList
        HashNode* next;

        HashNode(const string& name) :
            username(name), next(NULL) {}
    };

    HashNode* table[tablesize];

    // Improved hash function
    int hashUsername(const string& username) {
        unsigned long hash = 5381;
        for (char c : username) {
            hash = ((hash << 5) + hash) + c; // hash * 33 + c
        }
        return hash % tablesize;
    }

public:
    PlayerHashTable();
    ~PlayerHashTable();

    // Add player if not exists
    void addPlayer(const string& username);

    // Find mutual friends between two users
    void findMutualFriends(const string& user1,
        const string& user2,
        string mutualFriends[],
        int& count);

    // Get friend list for a username
    FriendList* getFriendList(const string& username);

    // Check if a user exists
    bool userExists(const string& username);

    // Remove a player
    void removePlayer(const string& username);
};

// Global hash table instance
extern PlayerHashTable playerHashTable;

#endif // PLAYER_HASH_H